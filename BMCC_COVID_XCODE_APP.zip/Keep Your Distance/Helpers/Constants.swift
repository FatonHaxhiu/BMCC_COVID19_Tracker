//
//  Constants.swift
//  Keep Your Distance
//
//  Created by Derek Dunn on 7/6/20.
//  Copyright © 2020 Derek Dunn. All rights reserved.
//

import Foundation

struct Constants {
    
    struct Storyboard {
        
        static let homeViewController = "HomeVC"
        
    }
    
    
}

